import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double num = Math.random() * 100;
        int n = (int) num;
        int score = 10;
        while (score != 0) {
            System.out.println("enter your guess--->");
            int guess = sc.nextInt();
            if (guess == n) {
                System.out.println("you won the match");
                System.out.println("your score is " + score);
                break;
            } else if (guess > n) {
                System.out.println("your guess is high");
                score--;
            } else {
                System.out.println("your guess is low");
                score--;
            }
        }
        if (score == 0) {
            System.out.println("retry");
        }
    }
}
