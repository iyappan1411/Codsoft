import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("welcome to the ayyapan ATM");
        System.out.println("enter initial amount");
        int amt = sc.nextInt();
        int n = 0;
        while (n != 4) {
            System.out.println("1-->deposite 2-->withdraw 3-->cheak balance -->exit");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    Deposite d = new Deposite();
                    amt = d.dep(amt);
                    break;
                case 2:
                    Withdraw w = new Withdraw();
                    amt = w.wdraw(amt);
                    break;
                case 3:
                    Balance b = new Balance();
                    b.bal(amt);
                    break;

                case 4:
                    System.out.println("thanks for visiting ");
            }
        }
    }
}

class Deposite {
    int dep(int amt) {
        Scanner x = new Scanner(System.in);
        System.out.println("enter deposite amount");
        int n = x.nextInt();
        amt = amt + n;
        System.out.println("deposite succesfully");
        return amt;
    }
}

class Withdraw {
    int wdraw(int amt) {
        Scanner x = new Scanner(System.in);
        System.out.println("enter withdraw amount");
        int n = x.nextInt();
        amt = amt - n;
        System.out.println("withdraw succesfully");
        return amt;
    }
}

class Balance {
    void bal(int amt) {
        System.out.println("your Balance is" + amt);
    }
}
