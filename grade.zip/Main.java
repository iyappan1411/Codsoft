import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        System.out.println("enter number of subject");
        int n = x.nextInt();
        int a[] = new int[n];
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            System.out.println("enter " + i + "th subject mark");
            a[i - 1] = x.nextInt();
            sum += a[i - 1];
        }
        if (90 < sum / n) {
            System.out.println("your grade is A");
        } else if (80 < sum / n) {
            System.out.println("your grade is B");
        } else if (70 < sum / n) {
            System.out.println("your grade is B");
        } else if (60 < sum / n) {
            System.out.println("your grade is B");
        } else if (50 < sum / n) {
            System.out.println("your grade is B");
        } else {
            System.out.println("sorry bro you fail");
        }
        double avg = sum / n;
        System.out.println("your total mark is" + sum);
        System.out.println("your avg mark is" + avg);
    }
}
